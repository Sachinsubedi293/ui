  
    AOS.init({
        duration: 2000,
        
      });
      var input = document.querySelector("#phone");
      window.intlTelInput(input, {
          separateDialCode: true,
          customPlaceholder: function (
              selectedCountryPlaceholder,
              selectedCountryData
          ) {
              return "e.g. " + selectedCountryPlaceholder;
          },
      });     